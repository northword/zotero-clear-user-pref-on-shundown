pref("extensions.zotero.test-plugin.feature-1", true);
pref("extensions.zotero.test-plugin.feature-1.option-1a", "");
pref("extensions.zotero.test-plugin.feature-2.option-2a", "");
